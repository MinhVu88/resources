The input file (democalculations.txt) shown in the demo clips is located in the CalcEngine folder along with the demo project and source code. 

As long as you're using the standard IntelliJ IDE configuration settings, the application should find the file in that location when you execute the program from within the IDE.