package com.pluralsight.improperexceptionuse;

public enum MathOperation {
    ADD,
    SUBTRACT,
    MULTIPLY,
    DIVIDE
}
